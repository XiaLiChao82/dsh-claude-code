// Filename bump for cordis-plugin-loader: it re-imports only when `name` changes.
// Implementation lives in main.v20.mjs (v24: DSH plan mode / read-only preset
// tighten the inner permission mode, and /goal forwards to the inner Claude
// Code session; other providers keep DSH's own goal handler verbatim).
export * from './main.v20.mjs'
