// Filename bump for cordis-plugin-loader: it re-imports only when `name` changes.
// Implementation lives in main.v20.mjs (v21 protocol: display-only tool-activity).
export * from './main.v20.mjs'
