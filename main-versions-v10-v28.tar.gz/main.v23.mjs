// Filename bump for cordis-plugin-loader: it re-imports only when `name` changes.
// Implementation lives in main.v20.mjs (v23: /compact routes to the inner
// Claude Code session for the claude-code-main route; every other provider is
// delegated to DSH's own compaction engine unchanged).
export * from './main.v20.mjs'
