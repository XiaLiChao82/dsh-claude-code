// Filename bump for cordis-plugin-loader: it re-imports only when `name` changes.
// Implementation lives in main.v20.mjs (v25: DSH's injected system prompt is
// filtered per paragraph — guidance for harness tools the inner Claude Code
// cannot call is dropped instead of being injected and then disclaimed).
export * from './main.v20.mjs'
