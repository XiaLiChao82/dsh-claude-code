// Filename bump for cordis-plugin-loader: it re-imports only when `name` changes.
// Implementation lives in main.v20.mjs (v27: DSH's bash is bridged and the
// native Bash is switched off, so the inner agent's command execution runs
// under DSH's file sandbox and approval flow instead of outside it).
export * from './main.v20.mjs'
