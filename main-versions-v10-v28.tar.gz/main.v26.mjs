// Filename bump for cordis-plugin-loader: it re-imports only when `name` changes.
// Implementation lives in main.v20.mjs (v26: DSH's goal tools are bridged into
// the inner Claude Code session through an in-process MCP server, so a goal
// attached to this provider can finally be completed instead of burning every
// automatic round).
export * from './main.v20.mjs'
