// Filename bump for cordis-plugin-loader: it re-imports only when `name` changes.
// Implementation lives in main.v20.mjs (v28: DSH's read/read_image/write/edit
// are bridged and the native Read/Write/Edit are switched off, so file writes
// join command execution inside DSH's sandbox; bridged calls appear in the
// transcript under the native names they replaced, leaving the
// mcp__server__tool shape to genuine third-party MCP servers).
export * from './main.v20.mjs'
