// llm-claude-code — Claude Code as a selectable DSH primary route.
//
// Claude Agent SDK owns the inner coding-agent/tool loop. DSH owns the outer
// session, model picker, cancellation, transcript, and effort selection. Native
// Claude tool calls are intentionally not re-emitted as DSH tool calls: doing so
// would execute them twice. DSH tool schemas arriving in `options.tools` are
// acknowledged with an explicit bridge note (see buildSystemAppend) instead of
// being silently dropped on the floor.
//
// v15 makes tool activity COLLAPSIBLE (the rename matters: cordis-plugin-
// loader re-imports a module only when the row's `name` changes — see
// cordis.patch.yml notes):
//   - Each completed inner tool run is now projected as a DSH REASONING block,
//     which the transcript renders as the collapsed-by-default Think-style
//     disclosure row: collapsed it reads `▸ Bash ✓ · git status`, expanded it
//     shows the command plus the display-clamped output. v13/v14's plain
//     Markdown text cards cannot fold — assistant text has no collapse
//     affordance — and the only other collapsible block kind, tool-call, is an
//     execution request DSH dispatches after the whole LLM stream (v12's
//     claude_activity echo produced exactly that end-of-turn pop-in and was
//     removed in v13). A reasoning block is emitted the instant the
//     tool_result arrives, renders in real time, folds natively, and is never
//     executed. Set llm-claude-code.toolActivityFold=false to fall back to the
//     v14 flat Markdown cards instead.
//   - Replay clamping now also covers these `▸ `-prefixed reasoning blocks the
//     same way legacy `‹ ` text blocks are clamped (800 chars per block in
//     text-history replay), so display-side folds never bloat full replays.
//   - Removes the dead claude_activity echo-tool registration left over from
//     the v12→v13 port: it referenced unimported defineTool/ACTIVITY_TOOL and
//     threw into its own catch on every apply.
//
// v14 refines v13 activity presentation (superseded by v15's fold default;
// kept behind llm-claude-code.toolActivityFold=false):
//   - An inner Claude Code tool run is now one completed Markdown code-card,
//     rather than separate `▸` call and `‹` result status blocks. The card holds
//     the native tool name, command/input, success/failure state, and output.
//     It is still ordinary assistant text: DSH's tool-call protocol is an
//     execution request which necessarily runs after the LLM stream, so using
//     it for an already-finished native call would again create a delayed card.
//     The trade-off is intentional: a card appears on native completion, not
//     while its command is still running.
//
// v11 adds over v10:
//   - Native session resume: instead of replaying the whole DSH history as
//     text every turn, the adapter tracks (per DSH session) the Claude Code
//     session id plus a watermark (the id of the last user message already
//     fed). When the next request's history still contains the watermark with
//     only our own assistant replies and trailing new user messages after it,
//     we resume that CC session (forkSession: true) and send ONLY the delta —
//     Claude then holds its own native tool results, thinking, and images, so
//     the replay-side truncation of ‹ blocks stops applying. Any divergence
//     (edited/deleted history, regenerated branch, a foreign-provider turn
//     after the watermark, missing watermark) falls back to full text replay
//     in a fresh session. persistSession is forced on while nativeResume is
//     enabled (resume needs the session file); a resume that fails because the
//     CC session vanished transparently retries once as full replay.
//
// v10 adds over v9 (the rename matters: cordis-plugin-loader re-imports a module
// only when the row's `name` changes — see cordis.patch.yml notes):
//   - Full-width tool activity display: the ▸ call line keeps up to 500 chars
//     (was 80); the ‹ result rendering preserves NEWLINES and shows up to
//     toolResultDisplayChars (default 3000, configurable) with a head+tail
//     ellipsis instead of a flat 240-char single-line cut. Replay-side, each
//     ‹ block is clamped to 800 chars in the next request's text history so
//     the display widening never bloats subsequent prompts.
//
// v9 adds over v8:
//   - Context windows realigned to the CLI 2.1.258 registry: fable/opus/sonnet
//     (current generation: fable-5, opus-5, sonnet-5) are NATIVE 1M
//     (window 1e6, native_1m) — the separate fable[1m] entry is gone since the
//     base alias already carries 1M. haiku stays 200k; a haiku[1m] suffix
//     variant is added (supports_1m_suffix in the registry).
//
// v8 adds over v7:
//   - Tool RESULT projection: native tool_result user messages now project as
//     "‹ Bash ✓ <output head>" status text beside the existing "▸ Bash · cmd"
//     call lines. Native cards remain impossible by design: DSH's tool-call
//     block is an EXECUTION request (dsh-agent-loop dispatches every one), so
//     replaying already-run inner tools as tool-call chunks would execute them
//     twice. The replayed result lines also hand Claude its own prior
//     inner-tool output (each turn is a fresh CLI session).
//
// v7 adds over v6:
//   - Model catalog: fable (Claude Fable 5 alias, subscription flagship with the
//     full effort ladder incl. xhigh/max) and fable[1m] (1M-context variant,
//     per-model contextWindow). Aliases verified against the 2.1.252 binary's
//     quick-switch list: haiku, fable, best, sonnet[1m], opus[1m], fable[1m],
//     opusplan. "fable" real-call verified on this subscription.
//
// v6 adds over v5:
//   - resolveWorkspace capture rewritten as a whitespace-free /-token: the v2
//     greedy capture backtracked to the LAST '.' of the line, so a system
//     prompt like "Working directory is /tmp. Answer in one sentence."
//     resolved the cwd to the WHOLE SENTENCE → execve ENOENT → every SDK
//     spawn failed inside dsh web with a misleading libc-mismatch message.
//   - spawnClaudeCodeProcess hook retained from the bisect: spawn via node
//     directly (detached) and surface the real code/syscall/errno on failure.
//
// v3/v4/v5 adds (consolidated):
//   - Image input: user-role image attachments are re-encoded through the
//     durable attachment service (readImageRequest, same pixel/byte policy
//     shape as dsh-llm-pi-ai) and delivered as base64 content blocks via the
//     SDK streaming-input channel (AsyncIterable<SDKUserMessage>). Every
//     user-role image is re-sent each turn — same replay semantics and the
//     same 20MiB aggregate guard as pi-ai — so follow-up questions about an
//     older screenshot keep working.
//   - Inner tool activity projection: complete SDK assistant messages expose
//     their tool_use blocks as compact status text blocks ("▸ Bash · git
//     status"), so long inner loops are no longer silent in the DSH transcript.
//     They are plain text, never tool-call-delta, so nothing executes twice.
//
// v2 fixes over main.mjs:
//   - resolveWorkspace no longer truncates paths containing '.' mid-path.
//   - settings integration: installSettingsSection hands setSource a FUNCTION;
//     the old `{...current}` spread of that function silently resolved to {} —
//     settings.yaml overrides never applied. config() now calls current().
//   - buildSystemAppend bridges the DSH tool catalog to native Claude tools.
import { spawn } from 'node:child_process'
import { query } from '@anthropic-ai/claude-agent-sdk'
import { LlmError, requestImageHandleText } from '@deepseek-ai/dsh-llm'
import { installSettingsSection, settingsNamespace } from '@deepseek-ai/dsh-settings'
import z from '@deepseek-ai/schemastery'

const NS = settingsNamespace('llm-claude-code')
const EFFORTS = ['low', 'medium', 'high', 'xhigh', 'max']
const MODELS = [
  // Context windows mirror the CLI 2.1.258 registry: the current generation
  // (fable-5, opus-5, sonnet-5, sonnet-4-6, opus-4-6+) is native 1M
  // (window 1e6, native_1m); only haiku-4-5 stays 200k with an optional
  // [1m] suffix variant (supports_1m_suffix).
  { id: 'fable', name: 'Claude Fable', description: 'Claude Code Fable 5 alias — subscription flagship; native 1M context, full effort ladder including xhigh/max.', context: 1000000 },
  { id: 'opus', name: 'Claude Opus', description: 'Claude Code Opus alias — strongest coding and reasoning; native 1M context.', context: 1000000 },
  { id: 'sonnet', name: 'Claude Sonnet', description: 'Claude Code Sonnet alias — balanced speed and capability; native 1M context.', context: 1000000 },
  { id: 'haiku', name: 'Claude Haiku', description: 'Claude Code Haiku alias — fastest and lightest; 200k context.', context: 200000 },
  { id: 'haiku[1m]', name: 'Claude Haiku · 1M', description: 'Haiku 4.5 with the 1M-context suffix variant.', context: 1000000 },
]
const DEFAULTS = {
  providerName: 'Claude Code · 订阅',
  contextWindow: 200000,
  partialMessages: true,
  showThinking: true,
  persistSession: false,
  showToolActivity: true,
  toolActivityFold: true,
  imageMaxPixels: 2048 * 2048,
  imageMaxBytes: 1024 * 1024,
  toolResultDisplayChars: 3000,
  nativeResume: true,
}

// Aggregate bound on base64 image payload per request, mirroring
// dsh-llm-pi-ai's DEFAULT_MAX_REQUEST_IMAGE_BYTES: every historical image is
// re-encoded into every request, so an unbounded history would eventually
// exceed the request-size cap and the session could never complete a turn.
const MAX_REQUEST_IMAGE_BYTES = 20 * 1024 * 1024

// The Anthropic Messages API accepts exactly these media types; the attachment
// store admits the same set, so anything else is refused loudly instead of
// surfacing as an opaque upstream 400.
const ANTHROPIC_MEDIA_TYPES = new Set(['image/png', 'image/jpeg', 'image/gif', 'image/webp'])

const Config = z.object({
  providerName: z.string(),
  binary: z.string(),
  workspace: z.string(),
  contextWindow: z.number().step(1).min(1),
  partialMessages: z.boolean(),
  showThinking: z.boolean(),
  persistSession: z.boolean(),
  showToolActivity: z.boolean(),
  toolActivityFold: z.boolean(),
  imageMaxPixels: z.number().step(1).min(1),
  imageMaxBytes: z.number().step(1).min(1),
  toolResultDisplayChars: z.number().step(1).min(0),
  nativeResume: z.boolean(),
})

const effortInfo = (id) => ({ id, name: id.charAt(0).toUpperCase() + id.slice(1) })

export const name = 'llm-claude-code'
export const inject = ['llm', 'subprocess']

export function modelInfo(provider, model, contextWindow = DEFAULTS.contextWindow) {
  const entry = MODELS.find((item) => item.id === model)
  return {
    provider,
    id: model,
    name: entry?.name ?? model,
    ...(entry?.description !== undefined ? { description: entry.description } : {}),
    inputModalities: ['text', 'image'],
    // Per-model context (e.g. the [1m] variants) overrides the configured default.
    context: { contextWindow: entry?.context ?? contextWindow },
    reasoning: { efforts: EFFORTS.map(effortInfo), defaultEffort: 'high' },
  }
}

/** Ordered deduped image refs from every user-role message, walking nested tool-result content. */
export function collectImageRefs(messages) {
  const refs = []
  const seen = new Set()
  const walk = (blocks) => {
    for (const block of blocks ?? []) {
      if (block?.type === 'image') {
        const id = block.attachment?.attachmentId
        if (id !== undefined && !seen.has(id)) {
          seen.add(id)
          refs.push(block.attachment)
        }
      } else if (block?.type === 'tool-result') {
        walk(block.content)
      }
    }
  }
  for (const message of messages ?? []) {
    if (message?.role === 'user') walk(message.content)
  }
  return refs
}

/** Base64 length of raw bytes, padding included. */
function base64Length(bytes) {
  return Math.ceil(bytes / 3) * 4
}

/**
 * Resolve request-image versions through the durable attachment service and
 * map them to Anthropic base64 image content blocks.
 * @returns Map<attachmentId, { block, handle }>
 */
export async function prepareImageBlocks(refs, attachments, policy, signal) {
  const prepared = new Map()
  let total = 0
  for (const ref of refs) {
    const version = await attachments.readImageRequest(ref, policy, signal)
    if (!ANTHROPIC_MEDIA_TYPES.has(version.mediaType)) {
      throw new LlmError(`llm-claude-code: image type ${version.mediaType} is not accepted by the Anthropic API`, 'UNSUPPORTED_CONTENT')
    }
    const data = Buffer.from(version.data).toString('base64')
    total += data.length
    if (total > MAX_REQUEST_IMAGE_BYTES) {
      throw new LlmError(`llm-claude-code: conversation images exceed the ${(MAX_REQUEST_IMAGE_BYTES / 1024 / 1024) | 0}MiB per-request image budget`, 'INVALID_REQUEST')
    }
    prepared.set(ref.attachmentId, {
      block: { type: 'image', source: { type: 'base64', media_type: version.mediaType, data } },
      handle: requestImageHandleText(version),
    })
  }
  return prepared
}

// Replay budget for one projected tool-activity block. The transcript shows
// the full rendering (toolResultDisplayChars); the next request's text
// replay clamps each `▸`/`‹` block to this many chars so long build logs don't
// bloat every subsequent prompt — Claude keeps the head, which is what it
// needs to recall its own prior inner-tool output.
const REPLAY_STATUS_MAX_CHARS = 800

function replayText(block) {
  const text = block?.text ?? ''
  const kind = block?.type
  // `‹ ` marks the legacy v8–v13 text status blocks; `▸ ` marks the v15 fold
  // blocks carried on the reasoning channel. Genuine Claude thinking never
  // starts with either sentinel, so it keeps replaying unclamped.
  if ((kind === 'text' || kind === 'reasoning') && (text.startsWith('‹ ') || text.startsWith('▸ ')) && text.length > REPLAY_STATUS_MAX_CHARS) {
    return `${text.slice(0, REPLAY_STATUS_MAX_CHARS).trimEnd()}\n… [replay truncated]`
  }
  return text
}

function blockText(block, images) {
  if (block?.type === 'text') return replayText(block)
  if (block?.type === 'reasoning') return replayText(block)
  if (block?.type === 'tool-call') return `[DSH tool request ${block.name}: ${block.arguments ?? ''}]`
  if (block?.type === 'tool-result') {
    const text = (block.content ?? []).filter((item) => item?.type === 'text').map((item) => item.text).join('')
    return `TOOL RESULT ${block.toolCallId}:\n${text || '(no output)'}`
  }
  if (block?.type === 'image') {
    const id = block.attachment?.attachmentId
    // Attached images carry the deterministic handle text so the model can tie
    // each in-position marker to the trailing image blocks; anything not in the
    // request (non-user roles are never collected) stays an explicit omission.
    if (id !== undefined && images.has(id)) return `[${images.get(id).handle}]`
    return '[image omitted: this route re-sends only user-role image attachments]'
  }
  return ''
}

export function serializeConversation(messages, images = new Map()) {
  const sections = []
  for (const message of messages ?? []) {
    const parts = (message.content ?? []).map((block) => blockText(block, images)).filter((text) => text.length > 0)
    if (parts.length === 0) continue
    const role = message.role === 'assistant' ? 'ASSISTANT' : message.role === 'system' ? 'SYSTEM' : 'USER'
    sections.push(`${role}:\n${parts.join('\n')}`)
  }
  return sections.join('\n\n')
}

/**
 * Wrap the serialized transcript (plus trailing image blocks) as an SDK prompt.
 * With images the prompt becomes a one-message AsyncIterable<SDKUserMessage>;
 * without images it stays a plain string so behavior is byte-identical to v2.
 */
export function buildSdkPrompt(promptText, imageBlocks) {
  if (imageBlocks.length === 0) return promptText
  const content = [{ type: 'text', text: promptText }, ...imageBlocks]
  async function* input() {
    yield { type: 'user', message: { role: 'user', content }, parent_tool_use_id: null }
  }
  return input()
}

function usageOf(usage) {
  return {
    inputTokens: usage?.input_tokens ?? 0,
    outputTokens: usage?.output_tokens ?? 0,
    ...(typeof usage?.cache_read_input_tokens === 'number' ? { cacheReadTokens: usage.cache_read_input_tokens } : {}),
    ...(typeof usage?.cache_creation_input_tokens === 'number' ? { cacheWriteTokens: usage.cache_creation_input_tokens } : {}),
  }
}

/**
 * Decide how this request reaches Claude Code.
 *
 * `stored` is the per-DSH-session tracking entry
 * `{ claudeSessionId, lastFedMessageId }` from the last fully successful
 * turn. Resume is only safe when the history is still a pure extension of
 * what that CC session already contains: the watermark message must still be
 * present, everything between it and the trailing user messages must be OUR
 * assistant replies (a foreign-provider turn after the watermark means the CC
 * session missed an exchange), and the new material must be exactly one
 * trailing run of user messages. Anything else — edits, deletions,
 * regeneration branches, retries, parallel forks — falls back to full text
 * replay in a fresh session.
 *
 * @returns { mode: 'full' } or
 *          { mode: 'resume', resumeId, delta, lastFedMessageId }
 */
export function planReplay(messages, stored, provider) {
  if (stored === undefined) return { mode: 'full' }
  const watermark = (messages ?? []).findIndex((message) => message?.id === stored.lastFedMessageId)
  if (watermark < 0) return { mode: 'full' }
  const after = messages.slice(watermark + 1)
  if (after.length === 0) return { mode: 'full' }
  // Only our assistant replies may appear before the new user input. A real
  // user-role tool result would mean DSH executed a tool that Claude Code's
  // native session never saw, so it is not a plain continuation.
  const firstUser = after.findIndex((message) => message?.role === 'user')
  if (firstUser < 0) return { mode: 'full' }
  for (let i = 0; i < firstUser; i++) {
    const message = after[i]
    if (message?.role !== 'assistant' || message?.source?.provider !== provider) return { mode: 'full' }
  }
  const delta = after.slice(firstUser)
  if (delta.length === 0) return { mode: 'full' }
  for (const message of delta) {
    if (message?.role !== 'user') return { mode: 'full' }
    if ((message.content ?? []).some((block) => block?.type === 'tool-result')) return { mode: 'full' }
  }
  return {
    mode: 'resume',
    resumeId: stored.claudeSessionId,
    delta,
    lastFedMessageId: after[after.length - 1].id,
  }
}

function sdkFailure(message) {
  const detail = Array.isArray(message?.errors) && message.errors.length > 0
    ? message.errors.join('; ')
    : message?.subtype ?? 'unknown Claude Code failure'
  const code = message?.subtype === 'error_max_turns' ? 'MAX_TOKENS' : 'PROVIDER_ERROR'
  return new LlmError(`llm-claude-code: ${detail}`, code)
}

const TOOL_INPUT_KEYS = ['command', 'file_path', 'path', 'pattern', 'url', 'query', 'description']
const TOOL_INPUT_MAX_CHARS = 500

/** The compact one-line description of one native tool_use's input. */
export function toolUseInputLine(use) {
  const input = use?.input ?? {}
  let detail = ''
  for (const key of TOOL_INPUT_KEYS) {
    const value = input[key]
    if (typeof value === 'string' && value.length > 0) {
      detail = value
      break
    }
    if (Array.isArray(value) && value.length > 0 && typeof value[0] === 'string') {
      detail = value.join(' ')
      break
    }
  }
  if (detail === '') detail = JSON.stringify(input)
  return detail.replace(/\s+/g, ' ').trim().slice(0, TOOL_INPUT_MAX_CHARS)
}

/** One compact human-readable line per native tool_use block. */
export function describeToolUses(uses) {
  return uses.map((use) => `▸ ${use?.name ?? 'tool'} · ${toolUseInputLine(use)}`).join('\n')
}

/**
 * Render one native tool_result content (string or block array) for DISPLAY:
 * newlines are preserved and long output keeps both ends — the head carries
 * what was asked for, the tail carries the exit status / final lines.
 * @param maxChars total display budget (configurable toolResultDisplayChars)
 */
export function resultText(content, maxChars = DEFAULTS.toolResultDisplayChars) {
  const parts = typeof content === 'string'
    ? [content]
    : (content ?? []).filter((block) => block?.type === 'text').map((block) => block.text)
  const text = parts.join('\n').trim()
  if (maxChars <= 0 || text.length <= maxChars) return text
  const head = Math.floor(maxChars * 0.6)
  const tail = Math.floor(maxChars * 0.3)
  const omitted = text.length - head - tail
  return `${text.slice(0, head)}\n… [${omitted} chars omitted] …\n${text.slice(-tail)}`
}

/** One Markdown code card per completed inner native tool run. */
export function describeToolActivityCards(results, useOf, maxChars = DEFAULTS.toolResultDisplayChars) {
  const entries = []
  for (const block of results) {
    const use = useOf(block?.tool_use_id) ?? { name: 'tool', inputLine: '' }
    const mark = block?.is_error ? 'failed' : 'completed'
    const output = resultText(block?.content, maxChars) || '(no output)'
    // A dynamic-length fence preserves any backticks from a command or its
    // output without accidentally terminating the Markdown card early.
    const body = `$ ${use.inputLine || '(no input)'}\n\n${output}`
    const runs = body.match(/`+/g) ?? []
    const fence = '`'.repeat(Math.max(3, ...runs.map((run) => run.length + 1)))
    entries.push(`**${use.name}** · ${mark}\n\n${fence}sh\n${body}\n${fence}`)
  }
  return entries.join('\n\n')
}

/**
 * One collapsible fold per completed inner native tool run, carried on the
 * reasoning channel. The FIRST LINE is the summary the collapsed Think-style
 * row shows; the remainder is the expanded body — plain pre-wrap text, NOT
 * Markdown, so no fences or bold here. The leading `▸ ` doubles as the
 * replay-clamp sentinel shared with the legacy `‹ ` blocks.
 * @returns an array of fold texts, one per tool_result block
 */
export function describeToolActivityFolds(results, useOf, maxChars = DEFAULTS.toolResultDisplayChars) {
  return results.map((block) => {
    const use = useOf(block?.tool_use_id) ?? { name: 'tool', inputLine: '' }
    const mark = block?.is_error ? '✗' : '✓'
    const output = resultText(block?.content, maxChars) || '(no output)'
    const input = use.inputLine || '(no input)'
    return `▸ ${use.name} ${mark} · ${input}\n$ ${input}\n\n${output}`
  })
}

export async function* translateSdkMessages(messages, { showToolActivity = true, toolActivityFold = true, toolResultDisplayChars = DEFAULTS.toolResultDisplayChars, onResult } = {}) {
  const blocks = new Map()
  const toolUses = new Map()
  let nextIndex = 0
  let emittedText = false
  let result

  const emitTextBlock = (text) => {
    const index = nextIndex++
    // Status text must not set emittedText: the result.result fallback below
    // exists precisely for turns whose real text never streamed, and a
    // tool-only prefix must not suppress the final answer.
    return [
      { type: 'block-start', index, blockType: 'text' },
      { type: 'text-delta', index, text },
      { type: 'block-end', index, block: { type: 'text', text } },
    ]
  }

  const emitFoldBlock = (text) => {
    const index = nextIndex++
    // The reasoning channel renders as the transcript's collapsed-by-default
    // disclosure row (real-time, never executed). Like emitTextBlock it must
    // not set emittedText, or a tool-only turn would lose its final answer.
    return [
      { type: 'block-start', index, blockType: 'reasoning' },
      { type: 'reasoning-delta', index, text },
      { type: 'block-end', index, block: { type: 'reasoning', text } },
    ]
  }

  for await (const message of messages) {
    if (message?.type === 'stream_event' && message.parent_tool_use_id === null) {
      const event = message.event
      if (event?.type === 'content_block_start') {
        const native = event.content_block
        const kind = native?.type === 'text' ? 'text' : native?.type === 'thinking' || native?.type === 'redacted_thinking' ? 'reasoning' : undefined
        if (kind !== undefined) {
          const state = { index: nextIndex++, kind, text: '' }
          blocks.set(event.index, state)
          yield { type: 'block-start', index: state.index, blockType: kind }
        }
      } else if (event?.type === 'content_block_delta') {
        const state = blocks.get(event.index)
        if (state !== undefined) {
          const delta = event.delta
          const text = state.kind === 'text' ? delta?.text : delta?.thinking
          if (typeof text === 'string' && text.length > 0) {
            state.text += text
            if (state.kind === 'text') {
              emittedText = true
              yield { type: 'text-delta', index: state.index, text }
            } else {
              yield { type: 'reasoning-delta', index: state.index, text }
            }
          }
        }
      } else if (event?.type === 'content_block_stop') {
        const state = blocks.get(event.index)
        if (state !== undefined) {
          blocks.delete(event.index)
          yield {
            type: 'block-end',
            index: state.index,
            block: state.kind === 'text' ? { type: 'text', text: state.text } : { type: 'reasoning', text: state.text },
          }
        }
      }
      continue
    }
    if (message?.type === 'assistant' && message.parent_tool_use_id === null && showToolActivity) {
      // Retain native calls until their results arrive. A card is then emitted
      // at completion in the SDK stream, never as a delayed DSH tool request.
      const uses = (message.message?.content ?? []).filter((block) => block?.type === 'tool_use')
      for (const use of uses) {
        if (typeof use?.id === 'string') toolUses.set(use.id, { name: use.name ?? 'tool', inputLine: toolUseInputLine(use) })
      }
      continue
    }
    if (message?.type === 'user' && message.parent_tool_use_id === null && showToolActivity) {
      const results = Array.isArray(message.message?.content)
        ? message.message.content.filter((block) => block?.type === 'tool_result')
        : []
      if (results.length > 0) {
        if (toolActivityFold) {
          for (const fold of describeToolActivityFolds(results, (id) => toolUses.get(id), toolResultDisplayChars)) {
            yield* emitFoldBlock(fold)
          }
        } else {
          yield* emitTextBlock(describeToolActivityCards(results, (id) => toolUses.get(id), toolResultDisplayChars))
        }
        for (const block of results) toolUses.delete(block?.tool_use_id)
      }
      continue
    }
    if (message?.type === 'result') result = message
  }

  if (result === undefined) throw new LlmError('llm-claude-code: SDK ended without a result', 'EMPTY_RESPONSE')
  if (result.subtype !== 'success' || result.is_error) throw sdkFailure(result)
  if (!emittedText && typeof result.result === 'string' && result.result.length > 0) {
    const index = nextIndex++
    yield { type: 'block-start', index, blockType: 'text' }
    yield { type: 'text-delta', index, text: result.result }
    yield { type: 'block-end', index, block: { type: 'text', text: result.result } }
  }
  if (typeof onResult === 'function') {
    try { onResult(result) } catch { /* tracking must never break the stream */ }
  }
  yield { type: 'usage', usage: usageOf(result.usage) }
  yield { type: 'finish', reason: { kind: 'stop' } }
}

// The workspace path is a single non-whitespace token starting with '/'; the
// sentence around it (trailing period, further sentences) must never leak into
// the captured path. A greedy capture backtracks to the LAST '.' of the line
// (v2–v5 bug: "Working directory is /tmp. Answer in one sentence." resolved to
// the whole sentence → nonexistent cwd → child_process spawn ENOENT); a lazy
// one truncates at the FIRST dot, breaking dotted paths. Capturing a
// whitespace-free token and trimming trailing sentence punctuation handles
// both. Paths containing spaces are unsupported (and never occur in DSH
// system prompts).
const WORKSPACE_PATTERNS = [
  /[Ww]orking directory is (?:currently )?`?(\/[^\s`]+)`?(?=[.\n]|$)/,
  /(?:工作目录|当前目录)(?:是|为)\s*`?(\/[^\s`]+)`?(?=[。.\n]|$)/,
]

export function resolveWorkspace(options, configured) {
  if (typeof configured === 'string' && configured.length > 0) return configured
  const system = typeof options?.system === 'string' ? options.system : ''
  for (const pattern of WORKSPACE_PATTERNS) {
    const match = pattern.exec(system)
    if (match !== null) {
      const path = match[1].trim().replace(/[.。,，;；:：!！?？)）"'']+$/, '')
      if (path.startsWith('/')) return path
    }
  }
  return process.cwd()
}

export function buildSystemAppend(options, tools) {
  const sections = []
  const system = typeof options?.system === 'string' ? options.system.trim() : ''
  if (system.length > 0) sections.push(system)
  const names = (tools ?? []).map((tool) => tool?.name).filter((name) => typeof name === 'string' && name.length > 0)
  if (names.length > 0) {
    sections.push(
      'Tool routing note: this conversation runs through the Claude Agent SDK, which owns the tool loop with your native Claude Code tools. '
        + `The harness tool catalog (${names.join(', ')}) is NOT callable from here — any instruction above or below telling you to call those tools `
        + 'applies instead to your native Claude Code equivalents (Bash, Read, Edit, Write, Glob, Grep, WebFetch, …) under their own names. '
        + 'Do not emit harness-style tool-call blocks; use native tools directly.',
    )
  }
  return sections.join('\n\n')
}

export function apply(ctx, rawConfig = {}) {
  let current = () => rawConfig
  const config = () => ({ ...DEFAULTS, ...current() })
  const logger = ctx.logger
  // Per-DSH-session native-resume tracking: dsh session key →
  // { claudeSessionId, lastFedMessageId }. In-memory only — a host restart
  // simply falls back to one full-replay turn and re-seeds the entry.
  const resumeState = new Map()

  // v12 registered a claude_activity echo tool here so finished inner tool
  // runs would reappear as native collapsible tool cards. v13 removed it (DSH
  // dispatches tool-call blocks only after the LLM stream, so the cards popped
  // in at end of turn) and the v12→v14 port left a half-dead registration
  // behind that referenced unimported identifiers and threw into its own
  // catch on every apply. v15 gets collapsibility from the reasoning-channel
  // folds instead — nothing to register.

  const adapter = {
    providerInfo(provider) {
      return { id: provider, name: config().providerName }
    },
    providerRetryPolicy() {
      return undefined
    },
    async listModels(provider) {
      return MODELS.map((item) => ({
        provider,
        id: item.id,
        name: item.name,
        description: item.description,
        inputModalities: ['text', 'image'],
      }))
    },
    async resolveModel(provider, model) {
      return modelInfo(provider, model, config().contextWindow)
    },
    async prepareCall(provider, model, signal) {
      return {
        model: await this.resolveModel(provider, model, signal),
        stream: (options) => this.stream(options),
      }
    },
    async *stream(options) {
      if (options.signal?.aborted) throw new LlmError('llm-claude-code: request aborted', 'ABORTED')

      const resolved = config()
      const sessionKey = typeof options.sessionId === 'string' && options.sessionId.length > 0 ? options.sessionId : 'default'
      const plan = resolved.nativeResume
        ? planReplay(options.messages, resumeState.get(sessionKey), 'claude-code-main')
        : { mode: 'full' }
      let forceFull = plan.mode !== 'resume'

      const executable = typeof resolved.binary === 'string' && resolved.binary.length > 0
        ? resolved.binary
        : await ctx.subprocess.resolveExecutable('claude', {}, options.signal)
      const controller = new AbortController()
      const onAbort = () => controller.abort(options.signal?.reason)
      options.signal?.addEventListener('abort', onAbort, { once: true })
      const effort = options.reasoningEffort === undefined ? 'high' : String(options.reasoningEffort)
      const append = buildSystemAppend(options, options.tools)
      // Spawn the CLI through node directly (detached, like the dsh subprocess
      // service) and record the true spawn error: the SDK's default path wraps
      // any failure in a generic libc-mismatch message that hides the real
      // errno (here: ENOENT from a nonexistent cwd — see resolveWorkspace).
      const runQuery = (sdkPrompt, resumeOptions) => {
        let spawnFailure = null
        const spawnClaude = (spec) => {
          const child = spawn(spec.command, spec.args, {
            cwd: spec.cwd,
            env: spec.env,
            signal: spec.signal,
            stdio: ['pipe', 'pipe', 'pipe'],
            detached: true,
          })
          child.on('error', (error) => {
            spawnFailure = `${error?.code ?? 'ERR'} ${error?.syscall ?? ''} ${error?.message ?? ''}`
          })
          return child
        }
        const sdkQuery = query({
          prompt: sdkPrompt,
          options: {
            spawnClaudeCodeProcess: spawnClaude,
            abortController: controller,
            cwd: resolveWorkspace(options, resolved.workspace),
            pathToClaudeCodeExecutable: executable,
            model: options.model,
            effort,
            // Resume needs the session file on disk; force persistence while
            // nativeResume is enabled regardless of the legacy default.
            persistSession: resolved.nativeResume || resolved.persistSession,
            disallowedTools: ['AskUserQuestion'],
            includePartialMessages: resolved.partialMessages,
            ...(resolved.showThinking ? { thinking: { type: 'adaptive', display: 'summarized' } } : {}),
            ...(append.length > 0 ? {
              systemPrompt: {
                type: 'preset',
                preset: 'claude_code',
                append,
              },
            } : {}),
            ...resumeOptions,
          },
        })
        return { sdkQuery, spawnFailureOf: () => spawnFailure }
      }

      // One attempt = build the prompt for the current mode (delta-only when
      // resuming, full history otherwise) and stream it. A vanished CC session
      // flips to full replay and retries once.
      let resuming = !forceFull
      while (true) {
        const replayMessages = resuming ? plan.delta : options.messages
        const imageRefs = collectImageRefs(replayMessages)
        const attachments = imageRefs.length > 0 ? ctx.get('attachments') : undefined
        if (imageRefs.length > 0 && attachments === undefined) {
          throw new LlmError('llm-claude-code: image input requires the durable attachment service', 'UNSUPPORTED_CONTENT')
        }
        const images = imageRefs.length > 0
          ? await prepareImageBlocks(imageRefs, attachments, { maxPixels: resolved.imageMaxPixels, maxBytes: resolved.imageMaxBytes }, options.signal)
          : new Map()
        let prompt
        if (resuming) {
          prompt = plan.delta
            .map((message) => (message.content ?? []).map((block) => blockText(block, images)).filter((text) => text.length > 0).join('\n'))
            .filter((text) => text.length > 0)
            .join('\n\n')
        } else {
          prompt = serializeConversation(options.messages, images)
        }
        if (prompt.trim().length === 0 && images.size === 0) throw new LlmError('llm-claude-code: request carried no usable text', 'INVALID_REQUEST')
        const sdkPrompt = buildSdkPrompt(prompt, [...images.values()].map((item) => item.block))
        const { sdkQuery, spawnFailureOf } = runQuery(sdkPrompt, resuming ? { resume: plan.resumeId, forkSession: true } : {})
        try {
          yield* translateSdkMessages(sdkQuery, {
            showToolActivity: resolved.showToolActivity,
            toolActivityFold: resolved.toolActivityFold,
            toolResultDisplayChars: resolved.toolResultDisplayChars,
            onResult: (result) => {
              if (typeof result?.session_id !== 'string' || result.session_id.length === 0) return
              if (resuming) {
                // forkSession writes each resumed turn to a NEW session id.
                resumeState.set(sessionKey, { claudeSessionId: result.session_id, lastFedMessageId: plan.lastFedMessageId })
              } else {
                const lastUser = [...(options.messages ?? [])].reverse().find((message) => message?.role === 'user')
                if (lastUser?.id !== undefined) resumeState.set(sessionKey, { claudeSessionId: result.session_id, lastFedMessageId: lastUser.id })
              }
            },
          })
          return
        } catch (error) {
          const message = error instanceof LlmError ? error.message : String(error?.message ?? error)
          // A resumed session may have been garbage-collected by Claude Code
          // itself; retry once as a full replay before surfacing the failure.
          if (resuming && /session|resume|conversation/i.test(message)) {
            sdkQuery.close()
            resumeState.delete(sessionKey)
            resuming = false
            continue
          }
          if (error instanceof LlmError) throw error
          const detail = spawnFailureOf() !== null ? ` [claude spawn: ${spawnFailureOf()}]` : ''
          throw new LlmError(`llm-claude-code: ${error?.message ?? error}${detail}`, error?.code === 'MAX_TOKENS' ? 'MAX_TOKENS' : 'PROVIDER_ERROR')
        } finally {
          options.signal?.removeEventListener('abort', onAbort)
          sdkQuery.close()
        }
      }
    },
  }

  ctx.llm.registerConfigurableProviders([
    { provider: 'claude-code-main', displayName: config().providerName, settingsNs: NS, settingsPath: [] },
  ])
  ctx.llm.registerAdapter(['claude-code-main'], adapter)
  installSettingsSection(ctx, NS, Config, rawConfig, {
    setSource: (source) => { current = source },
    onChange: () => {},
  })
  logger.info('provider "claude-code-main" registered — Claude Agent SDK owns the native coding-agent loop')
}
